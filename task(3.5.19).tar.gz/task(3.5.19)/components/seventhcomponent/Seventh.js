import React, { Component } from 'react';

export default class Seventh extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h1>Seventh Component</h1>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
