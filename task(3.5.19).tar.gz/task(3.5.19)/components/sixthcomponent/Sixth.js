import React, { Component } from 'react';

class Sixth extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h1>Sixth Component</h1>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Sixth;