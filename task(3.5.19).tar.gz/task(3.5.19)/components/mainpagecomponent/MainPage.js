import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './MainPage.css';
import HeaderComponent from './../headercomponent/HeaderComponent'
import FooterComponent from './../footercomponent/FooterComponent';
import First from './../firstcomponent/First';
import Second from './../secondcomponent/Second';
import Third from './../thirdcomponent/Third';
import Fourth from './../fourthcomponent/Fourth';
import Fifth from './../fifthcomponent/Fifth';
import Sixth from './../sixthcomponent/Sixth';
import Seventh from "../seventhcomponent/Seventh";

var data = require('./../../JSON/details.json');

class MainPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            datas : data
        }
        //console.log(this.state.datas);
    }

    componentLoad(evt){
        //alert(evt.target.value);
        switch(evt.target.value){
            case 0 : ReactDOM.render(<First/>, document.getElementById('Comp'));
                     break;
            case 1 : ReactDOM.render(<Second/>, document.getElementById('Comp'));
                     break;
            case 2 : ReactDOM.render(<Third/>, document.getElementById('Comp'));
                     break;
            case 3 : ReactDOM.render(<Fourth/>, document.getElementById('Comp'));
                     break;
            case 4 : ReactDOM.render(<Fifth/>, document.getElementById('Comp'));
                     break;
            case 5 : ReactDOM.render(<Sixth/>, document.getElementById('Comp'));
                     break;
            case 6 : ReactDOM.render(<Seventh/>, document.getElementById('Comp'));
                     break;
            default : return false;
        }
        
    }

    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <HeaderComponent></HeaderComponent>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-2 bordersLeft">
                        {   
                            (data[0].name != "") ?
                            <ul>
                                {   
                                    data[0].name.map((val, i) => {
                                        return <li key={i} value={i} onClick={this.componentLoad.bind(this)}>{val}<img src="tick.png" alt="TICK" className="tick"></img></li>
                                    })
                                }
                            </ul> : <p>NO DATA TO DISPLAY</p>
                        }
                        </div> 
                        <div className="col-md-10 bordersRight" id="Comp">
                            
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-12">
                            <FooterComponent></FooterComponent>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default MainPage;