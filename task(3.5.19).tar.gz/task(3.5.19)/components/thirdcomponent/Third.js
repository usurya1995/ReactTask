import React, { Component } from 'react';

class Third extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h1>Third Component</h1>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Third;