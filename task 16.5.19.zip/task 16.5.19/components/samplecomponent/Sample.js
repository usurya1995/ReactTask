import React, { Component } from 'react';

class Sample extends Component{
    constructor(props){
        super(props);
    }

    render(){
        var TagName = this.props.greeting;
        console.log(TagName);
        return <TagName />;
    }
}

export default Sample;