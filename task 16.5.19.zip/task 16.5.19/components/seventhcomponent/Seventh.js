import React, { Component } from 'react';
import './Seventh.css';
var Address4 = require('ip-address').Address4;

export default class Seventh extends Component {
    constructor(props) {
        super(props);

        this.state={
            ip : "",
            keys : ""
        }
    }

    handleIP(e){
        this.setState({ ip: e.target.value });
    }

    handleKey(e){
        this.setState({ keys: e.target.value });
        //this.state.keys = e.target.value;
    }

    handleClear(){
        this.setState({ 
            ip: "",
            keys: ""
         });
         document.getElementsByClassName("tick")[6].style.display="none";
    }

    onSub(e){
        var address = new Address4(this.state.ip);

        //alert(address.isValid());
        if(!address.isValid()){
            alert("Please enter valid ip address");
            e.preventDefault();
            return false;
        }
          
        if(isNaN(this.state.keys) || this.state.keys==""){
            alert("Please enter only number");
            e.preventDefault();
            return false;
        }

        if(address.isValid() && !isNaN(this.state.keys)){
            document.getElementsByClassName("tick")[6].style.display="block";
            e.preventDefault();
        }
    }

    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 style={{textAlign:"center"}}>Syslog</h2>
                            <form className="spaceTop" onSubmit={this.onSub.bind(this)}>
                                <label>IP ADDRESS&nbsp;<sup><i className="fa fa-star"></i></sup></label>
                                <br></br>
                                <input type="text" className="form-control" value={this.state.ip} onChange={this.handleIP.bind(this)} placeholder="Input a Site Profile name"></input>
                                <br></br>
                                <label>KEY</label>
                                <br></br>
                                <input type="text" className="form-control" value={this.state.keys} onChange={this.handleKey.bind(this)} placeholder="Enter Key"></input>
                                <br></br>
                                <div className="btndir">
                                    <button type="submit" className="btn btn-info">Save</button>
                                    <button className="btn btn-info" type="button" onClick={this.handleClear.bind(this)}>Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
