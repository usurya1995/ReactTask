import React, { Component } from 'react';

class Step1 extends Component {
    constructor(props) {
        super(props);

        this.state = {

        }
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h3>Signup</h3>
                            <form>
                                <div className="form-group">
                                    <label>First name</label>
                                    <br></br>
                                    <input type="name" className="form-control" id="name" placeholder="Enter name" />
                                </div>
                                <div className="form-group">
                                    <label>Last name</label>
                                    <br></br>
                                    <input type="address" className="form-control" id="address" placeholder="Enter address" />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Step1;