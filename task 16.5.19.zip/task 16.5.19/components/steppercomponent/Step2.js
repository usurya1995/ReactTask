import React, { Component } from 'react';

class Step2 extends Component {
    constructor(props) {
        super(props);

        this.state = {

        }
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h3>User Details</h3>
                            <form>
                                <div className="form-group">
                                    <label>Email</label>
                                    <br></br>
                                    <input type="name" className="form-control" placeholder="E-Mail" />
                                </div>
                                <div className="form-group">
                                    <label>Mobile Number</label>
                                    <br></br>
                                    <input type="address" className="form-control" placeholder="Mobile Number" />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Step2;