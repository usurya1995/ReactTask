import React, { Component } from 'react';
import './Second.css';
import './../mainpagecomponent/MainPage.css';

class Second extends Component {
    constructor(props) {
        super(props);
        this.check = true;
        this.radio = true;
    }

    handleClear(){
        this.check = true;
        this.radio = true;
        var checkBox1 = document.querySelectorAll("input[type='checkbox']");
        for(var i=0;i<checkBox1.length;i++){
            if(checkBox1[i].checked){
                checkBox1[i].checked = false;
            }  
        }
        var radioBtn1 = document.querySelectorAll("input[type='radio']");
        for(var j=0;j<radioBtn1.length;j++){
            if(radioBtn1[j].checked){
                radioBtn1[j].checked = false;
            }  
        }
        document.getElementsByClassName("tick")[1].style.display="none";
    }

    handleCheck(evt){
        console.log(evt.target.value);
    }

    onSub(evt){
        var checkBox = document.querySelectorAll("input[type='checkbox']");
        for(var i=0;i<checkBox.length;i++){
            if(checkBox[i].checked){
                this.check= false;
                evt.preventDefault();
            }  
        }
        var radioBtn = document.querySelectorAll("input[type='radio']");
        for(var j=0;j<radioBtn.length;j++){
            if(radioBtn[j].checked){
                this.radio= false;
                evt.preventDefault();
            }  
        }
        if(this.check)
        {
            alert("Please select atlest one check box");
            evt.preventDefault();
        }
        if(this.radio)
        {
            alert("Please Select radio button");
            evt.preventDefault();
        }
        if(!this.check && !this.radio){
            document.getElementsByClassName("tick")[1].style.display="block";
        }
        evt.preventDefault();
    }

    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 style={{ textAlign: "center" }}>LDAP</h2>
                            <form onSubmit={this.onSub.bind(this)}>
                                <label>TECHNOLOGIES:</label>
                                <br></br>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="checkbox" className="form-check-input" value="HTML" onChange={this.handleCheck.bind(this)}/>HTML
                                    </label>
                                </div>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="checkbox" className="form-check-input" value="CSS" onChange={this.handleCheck.bind(this)}/>CSS
                                    </label>
                                </div>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="checkbox" className="form-check-input" value="Javascript" onChange={this.handleCheck.bind(this)}/>Javascript
                                    </label>
                                </div>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="checkbox" className="form-check-input" value="React" onChange={this.handleCheck.bind(this)}/>React
                                    </label>
                                </div>
                                <br></br>
                                <br></br>
                                <label>PLEASE SELECT YOUR PREFERED CONTACT METHOD:</label>
                                <br></br>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="radio" className="form-check-input" name="optradio"/>E-Mail
                                    </label>
                                </div>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="radio" className="form-check-input" name="optradio"/>Phone
                                    </label>
                                </div>
                                <div className="form-check-inline disabled">
                                    <label className="form-check-label">
                                        <input type="radio" className="form-check-input" name="optradio"/>Skype
                                    </label>
                                </div>
                                <div className="btndir">
                                    <button type="submit" className="btn btn-info">Save</button>
                                    <button className="btn btn-info" type="button" onClick={this.handleClear.bind(this)}>Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Second;