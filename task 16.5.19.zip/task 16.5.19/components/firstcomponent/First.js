import React, { Component } from 'react';
import './First.css';
import './../mainpagecomponent/MainPage.css';
var Address4 = require('ip-address').Address4;

class First extends Component {
    constructor(props) {
        super(props);
        this.state={
            ip : "",
            keys : ""
        }
    }

    handleIP(e){
        this.setState({ ip: e.target.value });
    }

    handleKey(e){
        this.setState({ keys: e.target.value });
        //this.state.keys = e.target.value;
    }

    handleClear(){
        this.setState({ 
            ip: "",
            keys: ""
         });
        let x = document.getElementsByClassName("keyerrmsg")[0];
        x.innerText = "";
        let y = document.getElementsByClassName("iperrmsg")[0];
        y.innerText= "";
        document.getElementsByClassName("tick")[0].style.display="none";
    }

    onSub(e){
        var address = new Address4(this.state.ip);
        let msgElem = document.createElement("i");
        msgElem.setAttribute('class',"fa fa-times-circle");

        //alert(address.isValid());
        if(!address.isValid()){
            //alert("Please enter valid ip address");
            msgElem.innerText="Please enter valid IP address";
            let tempElem = document.getElementsByClassName("iperrmsg")[0];
            tempElem.appendChild(msgElem);
            e.preventDefault();
            return false;
        }
          
        if(isNaN(this.state.keys) || this.state.keys==""){
            //alert("Please enter only number");
            msgElem.innerText="Please enter only number";
            let tempElem = document.getElementsByClassName("keyerrmsg")[0];
            tempElem.appendChild(msgElem)
            e.preventDefault();
            return false;
        }

        if(address.isValid() && !isNaN(this.state.keys)){
            document.getElementsByClassName("tick")[0].style.display="block";
            let x = document.getElementsByClassName("keyerrmsg")[0];
            x.innerText = "";
            let y = document.getElementsByClassName("iperrmsg")[0];
            y.innerText= "";    
            e.preventDefault();
        }

        // if((this.state.ip.length != 0) && (this.state.keys.length != 0)){
        //     document.getElementsByClassName("tick")[0].style.display="block";
        //     e.preventDefault();
        // }
        // else
        // {  
        //     document.getElementsByClassName("tick")[0].style.display="none";
            
        // }
    }

    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 style={{textAlign:"center"}}>Authentication</h2>
                            <form className="spaceTop" onSubmit={this.onSub.bind(this)}>
                                <label>TACAS IP ADDRESS&nbsp;<sup><i className="fa fa-star"></i></sup></label>
                                <br></br>
                                <input type="text" className="form-control" value={this.state.ip} onChange={this.handleIP.bind(this)} placeholder="Input a Site Profile name"></input>
                                <br></br>
                                <div className="iperrmsg" style={{color:"red"}}></div>
                                <label>KEY</label>
                                <br></br>
                                <input type="text" className="form-control" value={this.state.keys} onChange={this.handleKey.bind(this)} placeholder="Enter Key"></input>
                                <br></br>
                                <div className="keyerrmsg" style={{color:"red"}}></div>
                                <div className="btndir">
                                    <button type="submit" className="btn btn-info">Save</button>
                                    <button className="btn btn-info" type="button" onClick={this.handleClear.bind(this)}>Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default First;