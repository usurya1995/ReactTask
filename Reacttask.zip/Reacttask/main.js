import React from 'react';
import ReactDOM from 'react-dom';
import Login from './components/logincomponent/Login';
import history from './components/historycomponent/history';
import { Switch, Route, BrowserRouter as Router } from 'react-router-dom';
import MainPage from './components/mainpagecomponent/MainPage';

const routing = (
    <Router history={history}>
      <Switch>
        <Route exact path="/" component={Login} />
        <Route path="/home" component={MainPage} />
      </Switch>
    </Router>
)

ReactDOM.render(routing, document.getElementById('rootUI'));