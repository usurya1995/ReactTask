import React, { Component } from 'react';
import FooterComponent from './../footercomponent/FooterComponent';
import './Login.css';
var data = require('./../../JSON/login.json');

class Login extends Component {
   constructor(props) {
      super(props);
      this.state = {
         user: "",
         pass: ""
      }
      this.updateUser = this.updateUser.bind(this);
      this.updatePass = this.updatePass.bind(this);
      this.updateDetails = this.updateDetails.bind(this);
   }

   updateUser(e) {
      this.setState({ user: e.target.value });
   }

   updatePass(e) {
      this.setState({ pass: e.target.value });
   }

   updateDetails(e) {
      //e.preventDefault();
      //alert("Username:" + this.state.user + "," + "Password:" + this.state.pass);
      //this.props.history.push(`/home/${this.state.user}`);
      
         //---OLD---
      // if(this.state.user != "" && this.state.pass != ""){
      //    this.props.history.push(`/home`);
      // }
      // else{
      //    alert("Please Enter Details");
      //    e.preventDefault();
      // }

      if(data[this.state.user]!= undefined){
         if(data[this.state.user] == this.state.pass){
            this.props.history.push(`/home`);
         }
      }
      else{
         alert("User Not Found");
         this.setState({"user": "","pass":""});
         document.getElementsByName("username")[0].value = "";
         document.getElementsByName("password")[0].value = "";
         e.preventDefault();
      }
   }

   render() {
      return (
         <div>
            <div className="container-fluid">
            <div className="row bgimgs">
               <div className="col-md-4">
                  
               </div>
               <div className="col-md-4 borsty">
                  {/* <h1>LOGIN</h1> */}
                  <img src="image1.png" alt="CISCO" className="img-size"></img>
                  <form onSubmit={this.updateDetails} className="login-form">
                     {/* <label>Username:</label> */}
                     <input type="text" className="form-control" name="username" value={this.state.user} onChange={this.updateUser} placeholder="Username"/><br />
                     {/* <label>Password:</label> */}
                     <input type="password" className="form-control" name="password" value={this.state.pass} onChange={this.updatePass} placeholder="Password"/><br />
                     <input type="submit" value="Submit" />
                  </form>
               </div>
               <div className="col-md-4"></div>
            </div>
            <footer>
                  <FooterComponent></FooterComponent>
            </footer>
            </div>
         </div>
      );
   }
}
export default Login;


// css


// .login-form {
//     width: 300px;
//     margin: 0 auto;
//     font-family: Tahoma, Geneva, sans-serif;
// }
// h1 {
//     text-align: center;
//     color: #4d4d4d;
//     padding: 0px 0 20px 0;
//     color: #3FB6E3;
// }
// .login-form input[type="password"],
// .login-form input[type="text"] {
    
//     padding: 15px;
//     border: 1px solid #dddddd;
//     margin-top: 20px;
//     margin-bottom: 15px;
//     box-sizing:border-box;
//     border-top:0px;
//     border-right: 0px;
//     border-left: 0px;
//     border-bottom: 1px solid;
//     border-radius: 0px;
// }
// .form-control:focus
// {
//     border-color: inherit;
//     box-shadow: none;
// }

// .login-form input[type="submit"] {
//     width: 100%;
//     padding: 15px;
//     background-color: #3FB6E3;
//     border: 0;
//     box-sizing: border-box;
//     cursor: pointer;
//     font-weight: bold;
//     color: #ffffff;
//     border-radius: 5px;
// }

// .img-size{
//     max-width: 20%;
//     margin-left: 190px;
//     margin-top: 15px;
// }

// .borsty{
//     margin-top: 165px;
//     padding: 15px;
//     border: 1px solid black;
//     border-radius: 10px;
//     background-color: white;
//     margin-left: auto;
//     margin-right: auto;
// }

// .bgimgs{
//     background-image: url("./../../bgm.jpg");
//         background-repeat: no-repeat;
//     background-size: 100%;
// }