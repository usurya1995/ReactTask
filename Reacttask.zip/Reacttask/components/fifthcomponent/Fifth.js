import React, { Component } from 'react';

class Fifth extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h1>Fifth Component</h1>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Fifth;