import React, { Component } from 'react';
import Spinner from './../spinnercomponent/Spinner'

class Sixth extends Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 style={{textAlign:"center"}}>DNS</h2>
                            
                            <span style={{display:"inline-flex"}}>
                                <p>Loading...</p>&nbsp;
                                <Spinner></Spinner>
                                <Spinner></Spinner>
                                <Spinner></Spinner>
                                <Spinner></Spinner>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Sixth;