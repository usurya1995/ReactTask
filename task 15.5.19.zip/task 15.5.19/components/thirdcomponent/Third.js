import React, { Component } from 'react';
import './Third.css';

class Third extends Component {
    constructor(props) {
        super(props);

        this.state={
            user:"",
            mail:""
        }
        this.radio = true;
    }

    hadleUser(evt){
        this.setState({
            user : evt.target.value
        })
    }

    hadleMail(evt){
        this.setState({
            mail : evt.target.value
        })
    }

    handleClear(){
        this.radio = true;
        this.setState({ 
            user: "",
            mail: ""
         });
        var radioBtn1 = document.querySelectorAll("input[type='radio']");
        for(var j=0;j<radioBtn1.length;j++){
            if(radioBtn1[j].checked){
                radioBtn1[j].checked = false;
            }  
        }
        document.getElementsByClassName("tick")[2].style.display="none";
    }

    onSub(evt){

        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        var emailval = this.state.mail;
        var radioBtn = document.querySelectorAll("input[type='radio']");
        for(var j=0;j<radioBtn.length;j++){
            if(radioBtn[j].checked){
                this.radio= false;
                evt.preventDefault();
            }  
        }

        if(this.state.user.trim()== ""){
            alert("Please enter user name");
            evt.preventDefault();
        }else if(this.state.user.length < 6){
            alert("Please enter atleast 7 character");
            evt.preventDefault();
        }else if(reg.test(emailval) == false){
            alert('Invalid Email Address');
            evt.preventDefault();
        }else if(this.radio){
            alert("Please Select radio button");
            evt.preventDefault();
        }else if(this.state.user !="" && this.state.mail != ""){
            document.getElementsByClassName("tick")[2].style.display="block";
        }
        evt.preventDefault();
    }

    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 style={{textAlign:"center"}}>Netflow</h2>
                            <form onSubmit={this.onSub.bind(this)}>
                                <label>USERNAME</label> 
                                <br></br>
                                <input type="text" className="form-control" value={this.state.user} onChange={this.hadleUser.bind(this)}></input>
                                <br></br>
                                <label>E-MAIL</label> 
                                <br></br>
                                <input type="text" className="form-control" value={this.state.mail} onChange={this.hadleMail.bind(this)}></input>
                                <br></br>
                                <label>GENDER</label>
                                <br></br>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="radio" className="form-check-input" name="optradio"/>MALE
                                    </label>
                                </div>
                                <div className="form-check-inline">
                                    <label className="form-check-label">
                                        <input type="radio" className="form-check-input" name="optradio"/>FEMALE
                                    </label>
                                </div>
                                <br></br>
                                <div className="btndir">
                                    <button type="submit" className="btn btn-info">Save</button>
                                    <button className="btn btn-info" type="button" onClick={this.handleClear.bind(this)}>Reset</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>   
            </div>
        );
    }
}
export default Third;