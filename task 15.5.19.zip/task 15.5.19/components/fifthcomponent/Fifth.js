import React, { Component } from 'react';
import './Fifth.css';

class Fifth extends Component {
    constructor(props) {
        super(props);

        this.state={

        }
    }


    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <h2 style={{textAlign:"center"}}>NTP</h2>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Fifth;